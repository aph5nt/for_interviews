﻿using Shared.Providers;

namespace WebApi.Providers
{
    public interface IRemoteUserWithdrawProvider : IRemoteActorProvider
    {
    }
}