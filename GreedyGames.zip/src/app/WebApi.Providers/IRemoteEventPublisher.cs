﻿using Shared.Providers;

namespace WebApi.Providers
{
    public interface IRemoteEventPublisher : IRemoteActorProvider
    {
    }
}