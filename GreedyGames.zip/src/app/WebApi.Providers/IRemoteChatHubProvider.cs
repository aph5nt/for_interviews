﻿using Shared.Providers;

namespace WebApi.Providers
{
    public interface IRemoteChatHubProvider : IRemoteActorProvider
    {
        
    }
}