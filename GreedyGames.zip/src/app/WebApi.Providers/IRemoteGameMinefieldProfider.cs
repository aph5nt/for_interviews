﻿using Shared.Providers;

namespace WebApi.Providers
{
    public interface IRemoteGameMinefieldProfider : IRemoteActorProvider
    {
    }
}