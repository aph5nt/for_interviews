﻿namespace Payment.Messages.Models
{
    public enum NotificationType
    {
        Server,
        Balance,
        Deposit,
        Withdraw
    }
}