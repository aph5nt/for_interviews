﻿namespace Payment.Actors
{
    public class NotificationMessages
    {
        public const string Connect = "CONNECT";
        public const string Connected = "CONNECTED";
        public const string Closed = "CLOSED";
    }
}
