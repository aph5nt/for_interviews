﻿namespace WebApi.Configuration
{
    public class Withdraw
    {
        public long MinAmount { get; set; }
        public long MaxAmount { get; set; }
    }
}