﻿namespace WebApi.Configuration
{
    public class Recaptcha
    {
        public string SiteKey { get; set; }
        public string SecretKey { get; set; }
    }
}