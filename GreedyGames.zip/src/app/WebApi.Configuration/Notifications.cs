﻿namespace WebApi.Configuration
{
    public class Notifications
    {
        public string UserPassword { get; set; }
        
        public string UserName { get; set; }
    }
}