﻿namespace Web.Providers
{
    public interface IWavesGatewayProvider : IActorSelectionProvider
    {
    }
}