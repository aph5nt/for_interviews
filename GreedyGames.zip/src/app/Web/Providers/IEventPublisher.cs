﻿namespace Web.Providers
{
    public interface IEventPublisher : IActorSelectionProvider
    {
    }
}