﻿namespace Web.Providers
{
    public interface IUserWithdrawProvider : IActorSelectionProvider
    {
    }
}