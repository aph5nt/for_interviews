﻿namespace Web.Providers
{
    public interface IGameMinefieldProfider : IActorSelectionProvider
    {
    }
}