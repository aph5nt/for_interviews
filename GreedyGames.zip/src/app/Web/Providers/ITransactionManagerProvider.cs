﻿namespace Web.Providers
{
    public interface ITransactionManagerProvider : IActorSelectionProvider
    {
    }
}