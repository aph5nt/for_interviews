﻿$('button.back-button').on("click", function () {
    window.history.back();
});