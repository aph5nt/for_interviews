export const environment = {
  production: true,
  apiBaseUrl: 'http://greedyrun.com'
};
