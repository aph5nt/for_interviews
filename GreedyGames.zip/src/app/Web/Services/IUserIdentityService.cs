namespace Web.Services
{
    public interface IUserIdentityService
    {
        string CreateUserIdentity();
    }
}