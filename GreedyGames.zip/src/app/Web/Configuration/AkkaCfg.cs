﻿namespace Web.Configuration
{
    public class AkkaCfg
    {
        public int Port { get; set; }
        public string Hostname { get; set; }
        public string PublicHostname { get; set; }
        public string AppServerUrl { get; set; }
    }
}