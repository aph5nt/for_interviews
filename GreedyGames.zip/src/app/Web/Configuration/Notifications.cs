﻿namespace Web.Configuration
{
    public class Notifications
    {
        public string ServerToken { get; set; }
    }
}