﻿namespace Web.Configuration
{
    public class Tokens
    {
        public string Issuer { get; set; }
        public string Key { get; set; }
    }
}