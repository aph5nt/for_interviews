﻿namespace Web.Configuration
{
    public class Session
    {
        public int Idle { get; set; }
    }
}