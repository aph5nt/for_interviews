﻿using Shared.Providers;

namespace Payment.Contracts.Providers
{
    public interface IWavesActorProvider : IActorProvider
    {

    }
}