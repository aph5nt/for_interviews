﻿namespace Payment.Contracts.Services
{
    //public interface IWithdrawRepository
    //{
    //    void Add(Withdraw userWithdraw);
    //    void Confirm(long withdrawId);
    //    void Fail(long withdrawId);
    //    void SaveChanges();
    //}
}
