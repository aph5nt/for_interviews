﻿namespace Payment.Contracts.Services
{
    //public interface IDepositRepository
    //{
    //    void Add(Deposit deposit);
    //    void SaveChanges();
    //    void Fail(long id);
    //    void Confirm(long id);
    //}
}
