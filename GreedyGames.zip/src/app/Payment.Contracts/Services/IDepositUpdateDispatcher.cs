namespace Payment.Contracts.Services
{
    //public interface IDepositUpdateDispatcher
    //{
    //    void Execute(Deposit deposit);
    //}
}