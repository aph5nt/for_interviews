﻿namespace Payment.Contracts.Services
{
    //public interface IUserWithdrawUpdateDispatcher
    //{
    //    void Execute(UserWithdraw withdraw);
    //}
}