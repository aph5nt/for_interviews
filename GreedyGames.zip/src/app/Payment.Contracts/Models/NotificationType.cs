﻿namespace Payment.Contracts.Models
{
    public enum NotificationType
    {
        Server,
        Balance,
        Deposit,
        Withdraw
    }
}