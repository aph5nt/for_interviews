﻿namespace Chat.Contracts.Queries
{
    public class GetConnectionCount
    {
    }
}