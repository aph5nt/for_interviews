﻿using System.Collections.Generic;

namespace Chat.Contracts.DataTransfer
{
    public class ChatArchive
    {
        public List<ChatMessage> Messages { get; set; }
    }
}