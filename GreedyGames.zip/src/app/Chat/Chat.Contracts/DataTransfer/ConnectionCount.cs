﻿namespace Chat.Contracts.DataTransfer
{
    public class ConnectionCount
    {
        public int Count { get; set; }
    }
}