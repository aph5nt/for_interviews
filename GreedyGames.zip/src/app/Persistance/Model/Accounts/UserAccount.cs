namespace Persistance.Model.Accounts
{
    public class UserAccount : Account
    {
        public bool IsActive { get; set; }
    }
}