namespace Persistance.Model.Accounts
{
    public class GameAccount : Account
    {
        public long Treshold { get; set; }
    }
}